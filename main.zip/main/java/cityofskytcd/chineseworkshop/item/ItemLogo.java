package cityofskytcd.chineseworkshop.item;

import net.minecraft.item.Item;

public class ItemLogo extends Item {
	public ItemLogo() {
		super();
		this.setUnlocalizedName("logo");
	}
}